#!/bin/zsh
echo This application is a GUI for the BarryKN Micropatcher.
echo Thanks to iPixelGalaxy, BarryKN, ASentientBot and others

if [ ! -e /Applications/Install\ macOS\ Big\ Sur\ Beta.app ]; then
        echo Please Download macOS Big Sur.app. Contact ASentientHedgehog#4406 on Discord for support.
        exit
fi

 lttstore.com
 
if [ ! -d /Volumes/USB ]; then
 echo /Volumes/USB is not mounted, please confirm that your USB is detected by the machine and named "USB"
 exit
fi

echo Running createinstallmedia. DO NOT CLOSE.
echo To check to see if createinstallmedia is progressing, open Activity Monitor and search createinstallmedia.

/Applications/Install\ macOS\ Big\ Sur\ Beta.app/Contents/Resources/createinstallmedia --volume /Volumes/USB --nointeraction

echo Finished running createinstallmedia.  Thanks to iPixelGalaxy for the Install macOS Big Sur Beta.app check


if [ ! -d ~/Desktop/big-sur-micropatcher-main ]; then
    echo Please download the Micropatcher, and make sure it is called big-sur-micropatcher-main and place it on your Desktop.
    exit
fi

sh ~/Desktop/big-sur-micropatcher-main/micropatcher.sh

sh ~/Desktop/big-sur-micropatcher-main/install-setvars.sh

echo The patching process is now complete. You may now close this application and boot off of the USB.
