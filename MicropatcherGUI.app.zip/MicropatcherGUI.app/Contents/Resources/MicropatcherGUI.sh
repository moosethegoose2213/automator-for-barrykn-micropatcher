#!/bin/zsh
echo This application is a GUI for the BarryKN Micropatcher.
echo Thanks to iPixelGalaxy, BarryKN, ASentientBot and others


if [ ! -e /Applications/Install\ macOS\ Big\ Sur\ Beta.app ]; then
        cd ~/Downloads/
        echo 'Downloading InstallAssistant.pkg (12GB). This will take a while! You can check the progression in Downloads'
        curl -o "InstallAssistant.pkg" http://swcdn.apple.com/content/downloads/21/61/001-58883-A_349P9V4VSE/vgf6b2ccrg6y0mk0y526c8hw8knbdwko2v/InstallAssistant.pkg
        echo 'Please close this application and run InstallAssistant.pkg from the Downloads folder, then relaunch the application.'
fi

# lttstore.com
 
if [ ! -d /Volumes/USB ]; then
 echo '/Volumes/USB is not mounted, please confirm that your USB is detected by the machine and named "USB"'
 exit
fi

echo Running createinstallmedia. DO NOT CLOSE.
echo 'To check to see if createinstallmedia is progressing, open Activity Monitor and search createinstallmedia.'

/Applications/Install\ macOS\ Big\ Sur\ Beta.app/Contents/Resources/createinstallmedia --volume /Volumes/USB --nointeraction

echo 'Finished running createinstallmedia.  Thanks to iPixelGalaxy for the Install macOS Big Sur Beta.app check'


if [ ! -d ~/Desktop/big-sur-micropatcher-main ]; then
    echo 'Please download the Micropatcher, and make sure it is called big-sur-micropatcher-main and place it on your Desktop.'
    exit
fi

sh ~/Desktop/big-sur-micropatcher-main/micropatcher.sh

sh ~/Desktop/big-sur-micropatcher-main/install-setvars.sh

echo 'The patching process is now complete. You may now close this application and boot off of the USB.'
