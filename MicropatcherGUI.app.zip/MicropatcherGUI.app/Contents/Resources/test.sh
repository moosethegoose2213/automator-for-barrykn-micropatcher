#!/bin/bash
echo Running createinstallmedia

/Applications/Install\ macOS\ Big\ Sur\ Beta.app/Contents/Resources/createinstallmedia --volume /Volumes/USB --nointeraction

echo Running createinstallmedia

sh ~/Desktop/big-sur-micropatcher-main/micropatcher.sh

sh ~/Desktop/big-sur-micropatcher-main/install-setvars.sh

echo Done
